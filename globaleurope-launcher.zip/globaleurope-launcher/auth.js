/**
 * auth.js — GlobalEurope Launcher
 *
 * Microsoft : OAuth2 -> Xbox Live -> XSTS -> Minecraft (sans dépendance tierce)
 * Offline   : UUID déterministe OfflinePlayer compatible Bukkit/Paper
 * Stockage  : AES-256-GCM, clé dérivée de la machine
 */

'use strict';

const { BrowserWindow } = require('electron');
const crypto = require('crypto');
const path   = require('path');
const fs     = require('fs');
const os     = require('os');
const https  = require('https');

// ─── Chemins ──────────────────────────────────────────────────────────────────
const GE_DIR       = path.join(process.env.APPDATA || process.env.HOME, '.globaleurope');
const SESSION_FILE = path.join(GE_DIR, 'session.enc');

// ─── Microsoft OAuth ──────────────────────────────────────────────────────────
// Pour obtenir un CLIENT_ID valide :
//   1. Azure Portal → App registrations → New registration
//   2. Platform: Mobile/desktop, redirect: https://login.live.com/oauth20_desktop.srf
//   3. API permissions: XboxLive.signin (delegated)
//   4. Coller l'Application (client) ID ci-dessous
//
// En attendant on utilise le client_id de l'app Electron officielle Minecraft
// qui accepte encore les logins pour les comptes Microsoft associés à MC.
const CLIENT_ID    = process.env.GE_CLIENT_ID || 'cf015820-cafd-4d1b-a87c-c311d6bf84ba';
const REDIRECT_URI = 'https://login.live.com/oauth20_desktop.srf';
const SCOPE        = 'XboxLive.signin%20offline_access';
const OAUTH_URL    = 'https://login.live.com/oauth20_authorize.srf'
  + '?client_id='    + CLIENT_ID
  + '&response_type=code'
  + '&redirect_uri=' + encodeURIComponent(REDIRECT_URI)
  + '&scope='        + SCOPE
  + '&prompt=select_account';

// ─── Chiffrement AES-256-GCM ─────────────────────────────────────────────────
const APP_SALT = 'GE-Launcher-2026-SecretSalt!';

function deriveKey() {
  const id = [os.hostname(), os.platform(), os.arch(), (os.cpus()[0] || {}).model || ''].join('|');
  return crypto.pbkdf2Sync(id, APP_SALT, 100000, 32, 'sha256');
}
function encrypt(data) {
  const key = deriveKey(), iv = crypto.randomBytes(12);
  const c   = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([c.update(JSON.stringify(data), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64');
}
function decrypt(b64) {
  const buf = Buffer.from(b64, 'base64'), key = deriveKey();
  const d   = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
  d.setAuthTag(buf.subarray(12, 28));
  return JSON.parse(Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8'));
}

// ─── Session disque ───────────────────────────────────────────────────────────
function saveSession(s) {
  if (!fs.existsSync(GE_DIR)) fs.mkdirSync(GE_DIR, { recursive: true });
  fs.writeFileSync(SESSION_FILE, encrypt(serializeSession(s)), 'utf8');
}
function loadSession() {
  if (!fs.existsSync(SESSION_FILE)) return null;
  try { return decrypt(fs.readFileSync(SESSION_FILE, 'utf8')); }
  catch (e) { console.error('[auth] loadSession:', e.message); return null; }
}
function clearSession() {
  try { if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE); } catch {}
}

// Retourne un objet 100% JSON-pur, safe pour IPC
function serializeSession(s) {
  if (!s) return null;
  return {
    type:           s.type,
    username:       s.username,
    uuid:           s.uuid,
    accessToken:    s.accessToken,
    clientToken:    s.clientToken,
    userProperties: s.userProperties || '{}',
    skinUrl:        s.skinUrl,
    role:           s.role,
    expiresAt:      s.expiresAt,
    createdAt:      s.createdAt,
    msRefreshToken: s.msRefreshToken || null,
  };
}

// ─── Requête HTTPS (avec suivi de redirects) ─────────────────────────────────
function httpsRequest(options, body, _redirects) {
  _redirects = _redirects || 0;
  return new Promise(function(resolve, reject) {
    const req = https.request(options, function(res) {
      // Suivre les redirects 301/302/307/308
      if ((res.statusCode === 301 || res.statusCode === 302 ||
           res.statusCode === 307 || res.statusCode === 308) && res.headers.location) {
        if (_redirects > 5) { reject(new Error('Trop de redirections')); return; }
        try {
          const loc = new URL(res.headers.location);
          const newOpts = Object.assign({}, options, {
            hostname: loc.hostname,
            path:     loc.pathname + (loc.search || ''),
            method:   'GET',
          });
          delete newOpts.headers['Content-Length'];
          httpsRequest(newOpts, null, _redirects + 1).then(resolve).catch(reject);
        } catch(e) { reject(new Error('Redirect invalide: ' + res.headers.location)); }
        return;
      }

      let data = '';
      res.on('data', function(d) { data += d; });
      res.on('end', function() {
        if (!data.trim()) {
          reject(new Error('Réponse vide (HTTP ' + res.statusCode + ')'));
          return;
        }
        // Détecter HTML (erreur serveur)
        if (data.trim().startsWith('<')) {
          reject(new Error('Réponse HTML inattendue (HTTP ' + res.statusCode + ') — ' + data.slice(0, 150)));
          return;
        }
        try {
          resolve(JSON.parse(data));
        } catch(e) {
          reject(new Error('JSON parse error (HTTP ' + res.statusCode + '): ' + data.slice(0, 200)));
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(20000, function() { req.destroy(new Error('Timeout réseau')); });
    if (body) req.write(body);
    req.end();
  });
}

// ─── Chaîne OAuth Microsoft → Minecraft ──────────────────────────────────────
async function _getMsToken(code) {
  const body = 'client_id=' + CLIENT_ID
    + '&code=' + encodeURIComponent(code)
    + '&grant_type=authorization_code'
    + '&redirect_uri=' + encodeURIComponent(REDIRECT_URI)
    + '&scope=XboxLive.signin%20offline_access';

  return httpsRequest({
    hostname: 'login.live.com',
    path:     '/oauth20_token.srf',
    method:   'POST',
    headers:  { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) },
  }, body);
}

async function _refreshMsToken(refreshToken) {
  const body = 'client_id=' + CLIENT_ID
    + '&refresh_token=' + encodeURIComponent(refreshToken)
    + '&grant_type=refresh_token'
    + '&scope=XboxLive.signin%20offline_access';

  return httpsRequest({
    hostname: 'login.live.com',
    path:     '/oauth20_token.srf',
    method:   'POST',
    headers:  { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) },
  }, body);
}

async function _getXblToken(msAccessToken) {
  const body = JSON.stringify({
    Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: 't=' + msAccessToken },
    RelyingParty: 'http://auth.xboxlive.com',
    TokenType: 'JWT',
  });
  const r = await httpsRequest({
    hostname: 'user.auth.xboxlive.com',
    path:     '/user/authenticate',
    method:   'POST',
    headers:  { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Content-Length': Buffer.byteLength(body) },
  }, body);
  return { token: r.Token, uhs: r.DisplayClaims.xui[0].uhs };
}

async function _getXstsToken(xblToken) {
  const body = JSON.stringify({
    Properties: { SandboxId: 'RETAIL', UserTokens: [xblToken] },
    RelyingParty: 'rp://api.minecraftservices.com/',
    TokenType: 'JWT',
  });
  const r = await httpsRequest({
    hostname: 'xsts.auth.xboxlive.com',
    path:     '/xsts/authorize',
    method:   'POST',
    headers:  { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Content-Length': Buffer.byteLength(body) },
  }, body);
  if (r.XErr) {
    const msg = r.XErr === 2148916238 ? 'Compte Xbox requis — créez-en un sur xbox.com'
              : r.XErr === 2148916233 ? 'Compte Xbox non trouvé'
              : 'Erreur Xbox (XErr=' + r.XErr + ')';
    throw new Error(msg);
  }
  return r.Token;
}

async function _getMcToken(uhs, xstsToken) {
  const body = JSON.stringify({ identityToken: 'XBL3.0 x=' + uhs + ';' + xstsToken });
  return httpsRequest({
    hostname: 'api.minecraftservices.com',
    path:     '/authentication/login_with_xbox',
    method:   'POST',
    headers:  { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
  }, body);
}

async function _getMcProfile(accessToken) {
  return httpsRequest({
    hostname: 'api.minecraftservices.com',
    path:     '/minecraft/profile',
    method:   'GET',
    headers:  { 'Authorization': 'Bearer ' + accessToken },
  });
}

function _formatUuid(raw) {
  const h = raw.replace(/-/g, '');
  if (h.length !== 32) return raw;
  return [h.slice(0,8), h.slice(8,12), h.slice(12,16), h.slice(16,20), h.slice(20)].join('-');
}

async function _buildSession(ms, profile) {
  const uuid = _formatUuid(profile.id);
  const skin = (profile.skins || []).find(function(s) { return s.state === 'ACTIVE'; });
  const clientToken = crypto.randomBytes(16).toString('hex');

  const session = {
    type:           'microsoft',
    username:       profile.name,
    uuid:           uuid,
    accessToken:    ms.mcAccessToken,
    clientToken:    clientToken,
    userProperties: '{}',
    skinUrl:        (skin && skin.url) || ('https://crafatar.com/avatars/' + uuid + '?size=64&overlay=true'),
    role:           'Membre',
    expiresAt:      Date.now() + (ms.expires_in || 86400) * 1000,
    createdAt:      Date.now(),
    msRefreshToken: ms.refresh_token,
    // authObj pour MCLC (mémoire uniquement)
    _authObj: {
      access_token:    ms.mcAccessToken,
      client_token:    clientToken,
      uuid:            uuid,
      name:            profile.name,
      user_properties: '{}',
      meta: { type: 'msa', demo: false, legacy: false },
    },
  };
  saveSession(session);
  return session;
}

// ─── Login Microsoft (BrowserWindow) ─────────────────────────────────────────
async function microsoftLogin(parentWindow) {
  return new Promise(function(resolve, reject) {
    const win = new BrowserWindow({
      width: 520, height: 700,
      parent: parentWindow, modal: true,
      show: false, frame: true, resizable: false,
      title: 'Connexion Microsoft — GlobalEurope',
      backgroundColor: '#0a0f1e',
      webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true },
    });
    win.setMenuBarVisibility(false);
    win.loadURL(OAUTH_URL);
    win.once('ready-to-show', function() { win.show(); });

    let handled = false;

    async function handleUrl(url) {
      if (handled) return;
      if (!url.startsWith(REDIRECT_URI)) return;
      handled = true;
      if (!win.isDestroyed()) win.destroy();

      try {
        const u     = new URL(url);
        const code  = u.searchParams.get('code');
        const error = u.searchParams.get('error_description') || u.searchParams.get('error');
        if (error) { reject(new Error(decodeURIComponent(error.replace(/\+/g,' ')))); return; }
        if (!code)  { reject(new Error('Code OAuth manquant')); return; }

        // Échange du code
        const ms       = await _getMsToken(code);
        if (ms.error)  { reject(new Error(ms.error_description || ms.error)); return; }
        const xbl      = await _getXblToken(ms.access_token);
        const xsts     = await _getXstsToken(xbl.token);
        const mc       = await _getMcToken(xbl.uhs, xsts);
        if (mc.error || mc.errorMessage || !mc.access_token) {
          reject(new Error('Erreur Minecraft Services: ' + (mc.errorMessage || mc.error || 'Token manquant')));
          return;
        }
        const profile  = await _getMcProfile(mc.access_token);
        if (profile.error || profile.errorMessage || profile.path === '/minecraft/profile') {
          reject(new Error('Ce compte Microsoft ne possède pas Minecraft Java Edition.'));
          return;
        }

        const session = await _buildSession(
          { mcAccessToken: mc.access_token, expires_in: mc.expires_in, refresh_token: ms.refresh_token },
          profile
        );
        resolve(session);
      } catch (err) { reject(err); }
    }

    // Intercepte toutes les redirections possibles
    win.webContents.on('will-redirect', function(e, url) {
      if (url.startsWith(REDIRECT_URI)) { e.preventDefault(); handleUrl(url); }
    });
    win.webContents.on('will-navigate', function(e, url) {
      if (url.startsWith(REDIRECT_URI)) { e.preventDefault(); handleUrl(url); }
    });
    win.webContents.on('did-navigate', function(e, url) {
      if (url.startsWith(REDIRECT_URI)) handleUrl(url);
    });
    win.webContents.on('did-navigate-in-page', function(e, url) {
      if (url.startsWith(REDIRECT_URI)) handleUrl(url);
    });
    win.on('closed', function() { if (!handled) reject(new Error('Connexion annulée')); });
  });
}

// ─── Offline ──────────────────────────────────────────────────────────────────
function createOfflineSession(username) {
  const clean = (username || '').trim().replace(/[^a-zA-Z0-9_]/g, '').slice(0, 16);
  if (!clean || clean.length < 3)
    throw new Error('Pseudo invalide — 3 à 16 caractères alphanumériques.');

  // UUID déterministe Bukkit/Paper OfflinePlayer
  const hash = crypto.createHash('md5').update('OfflinePlayer:' + clean).digest('hex');
  const uuid = [
    hash.slice(0, 8), hash.slice(8, 12),
    '3' + hash.slice(13, 16),
    ((parseInt(hash[16], 16) & 0x3 | 0x8).toString(16)) + hash.slice(17, 20),
    hash.slice(20, 32),
  ].join('-');

  const accessToken = crypto.randomBytes(16).toString('hex');
  const clientToken = crypto.randomBytes(16).toString('hex');

  const session = {
    type: 'offline', username: clean, uuid,
    accessToken, clientToken, userProperties: '{}',
    skinUrl: 'https://crafatar.com/avatars/' + uuid + '?size=64&overlay=true',
    role: 'Hors-ligne', expiresAt: null, createdAt: Date.now(), msRefreshToken: null,
    _authObj: {
      access_token: accessToken, client_token: clientToken,
      uuid, name: clean, user_properties: '{}',
      meta: { type: 'offline', demo: false, legacy: false },
    },
  };
  saveSession(session);
  return session;
}

// ─── Refresh ──────────────────────────────────────────────────────────────────
async function refreshSessionIfNeeded(session) {
  if (!session || session.type === 'offline') return session;
  const expired = !session.expiresAt || (Date.now() + 5 * 60 * 1000) >= session.expiresAt;
  if (!expired) return session;
  if (!session.msRefreshToken) { clearSession(); return null; }

  try {
    const ms    = await _refreshMsToken(session.msRefreshToken);
    if (ms.error) { clearSession(); return null; }
    const xbl   = await _getXblToken(ms.access_token);
    const xsts  = await _getXstsToken(xbl.token);
    const mc    = await _getMcToken(xbl.uhs, xsts);
    if (!mc.access_token) { clearSession(); return null; }
    const profile = await _getMcProfile(mc.access_token);
    if (profile.error) { clearSession(); return null; }

    return _buildSession(
      { mcAccessToken: mc.access_token, expires_in: mc.expires_in, refresh_token: ms.refresh_token },
      profile
    );
  } catch (err) {
    console.error('[auth] refresh échoué:', err.message);
    clearSession(); return null;
  }
}

module.exports = { microsoftLogin, createOfflineSession, refreshSessionIfNeeded, loadSession, saveSession, clearSession, serializeSession };
