const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('launcher', {
  // Window controls
  minimize:  () => ipcRenderer.send('window-minimize'),
  maximize:  () => ipcRenderer.send('window-maximize'),
  close:     () => ipcRenderer.send('window-close'),

  // Navigation
  openShop:     () => ipcRenderer.send('open-shop'),
  openWebsite:  () => ipcRenderer.send('open-website'),
  openDiscord:  () => ipcRenderer.send('open-discord'),
  openExternal: (url) => ipcRenderer.send('open-external', url),

  // Auth
  authGetSession:  ()         => ipcRenderer.invoke('auth-get-session'),
  authMicrosoft:   ()         => ipcRenderer.invoke('auth-microsoft'),
  authOffline:     (username) => ipcRenderer.invoke('auth-offline', username),
  authLogout:      ()         => ipcRenderer.invoke('auth-logout'),

  // Game
  launchGame:       () => ipcRenderer.invoke('launch-game'),
  checkJava:        () => ipcRenderer.invoke('check-java'),

  // Mods
  getMods:          () => ipcRenderer.invoke('get-mods'),
  downloadMods:     () => ipcRenderer.invoke('download-mods'),
  getInstalledMods: () => ipcRenderer.invoke('get-installed-mods'),
  openModsFolder:   () => ipcRenderer.send('open-mods-folder'),

  // Settings
  saveSettings:   (s) => ipcRenderer.invoke('save-settings', s),
  loadSettings:   ()  => ipcRenderer.invoke('load-settings'),

  // Misc
  copyIP:      () => ipcRenderer.invoke('copy-ip'),
  checkServer: () => ipcRenderer.invoke('check-server'),
  getVersion:  () => ipcRenderer.invoke('get-version'),
  getModsDir:  () => ipcRenderer.invoke('get-mods-dir'),

  // Events (launch)
  onLaunchProgress: (cb) => ipcRenderer.on('launch-progress', (_, d) => cb(d)),
  onLaunchLog:      (cb) => ipcRenderer.on('launch-log',      (_, d) => cb(d)),
  onLaunchClosed:   (cb) => ipcRenderer.on('launch-closed',   (_, d) => cb(d)),

  // Events (download)
  onDownloadProgress: (cb) => ipcRenderer.on('download-progress', (_, d) => cb(d)),
  removeAllListeners: (ch)  => ipcRenderer.removeAllListeners(ch),
});
