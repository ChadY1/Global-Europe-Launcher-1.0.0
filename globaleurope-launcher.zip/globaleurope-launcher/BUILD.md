# Build GlobalEurope Launcher

## Prérequis
```bash
npm install
```

Ajouter les icônes dans `assets/` :
- `icon.ico`  → Windows (256x256 recommandé)
- `icon.icns` → macOS
- `icon.png`  → Linux (512x512)

---

## Windows (.exe installateur)
```bash
npm run build:win
# → dist/GlobalEurope Launcher Setup 1.0.0.exe
```

## macOS (.dmg)
```bash
npm run build:mac
# → dist/GlobalEurope Launcher-1.0.0.dmg
# Nécessite un Mac ou une CI (GitHub Actions)
```

## Linux (.AppImage + .deb)
```bash
npm run build:linux
# → dist/GlobalEurope Launcher-1.0.0.AppImage
# → dist/globaleurope-launcher_1.0.0_amd64.deb
```

## Toutes les plateformes d'un coup
```bash
npm run build:all
```

---

## GitHub Actions (build auto sur push)

Crée `.github/workflows/build.yml` :

```yaml
name: Build
on:
  push:
    tags: ['v*']

jobs:
  build:
    strategy:
      matrix:
        os: [windows-latest, ubuntu-latest, macos-latest]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm install
      - run: npm run dist
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      - uses: actions/upload-artifact@v4
        with:
          name: launcher-${{ matrix.os }}
          path: dist/
```

---

## Notes
- Le build Windows sur Linux/Mac nécessite Wine (`brew install --cask wine-stable`)
- Le build Mac ne peut se faire que sur macOS (codesigning Apple)
- Le build Linux fonctionne sur Windows/Mac/Linux
