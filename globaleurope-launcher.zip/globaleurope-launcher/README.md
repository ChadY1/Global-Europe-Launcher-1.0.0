# GlobalEurope Launcher

Launcher officiel du serveur Minecraft **GlobalEurope** — Cobblemon 1.21.1 Fabric.

## Installation

```bash
npm install
npm start          # Mode développement
npm run build:win  # Build Windows (.exe)
npm run build:mac  # Build macOS (.dmg)
npm run build:linux # Build Linux (.AppImage)
```

## Configuration

- Remplacez l'URL du Gist dans `main.js` (`GIST_URL`) par votre vrai Gist
- Remplacez `MODS_ZIP_URL` par l'URL de votre archive mods
- Remplacez les icônes dans `assets/` (icon.ico, icon.icns, icon.png)

## Structure

```
globaleurope-launcher/
├── main.js          ← Process principal Electron
├── preload.js       ← Bridge IPC sécurisé
├── mods.json        ← Liste des mods (depuis Gist)
├── renderer/
│   └── index.html   ← Interface complète du launcher
├── assets/
│   └── icon.*       ← Icônes de l'application
└── package.json     ← Config + build Electron Builder
```

## Liens

- Site : https://globaleurope.fr
- Boutique : https://pay.globaleurope.fr
- Serveur : play.globaleurope.fr:25565
