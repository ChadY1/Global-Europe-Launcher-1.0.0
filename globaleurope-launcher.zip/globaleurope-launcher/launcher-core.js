/**
 * launcher-core.js — GlobalEurope Launcher
 *
 * Sequence de lancement :
 *   1. Verification de Java 17+
 *   2. Telechargement du Fabric Installer JAR si absent
 *   3. Execution : java -jar fabric-installer.jar client -dir <gameDir> -mcversion 1.21.1 -noprofile
 *   4. Resolution du versionId Fabric installe
 *   5. Lancement via minecraft-launcher-core
 */

'use strict';

const { Client }          = require('minecraft-launcher-core');
const axios               = require('axios');
const path                = require('path');
const fs                  = require('fs');
const { execSync, spawn } = require('child_process');

const MC_VERSION = '1.21.1';

const FABRIC_INSTALLER_URL =
  'https://maven.fabricmc.net/net/fabricmc/fabric-installer/1.0.1/fabric-installer-1.0.1.jar';
const FABRIC_INSTALLER_JAR = 'fabric-installer-1.0.1.jar';
const FABRIC_META_URL = 'https://meta.fabricmc.net/v2/versions/loader/' + MC_VERSION;

// ─── Java detection ───────────────────────────────────────────────────────────
function detectJava() {
  const isWin = process.platform === 'win32';
  const exe   = isWin ? 'java.exe' : 'java';

  const candidates = [
    process.env.JAVA_HOME ? path.join(process.env.JAVA_HOME, 'bin', exe) : null,
    process.env.JRE_HOME  ? path.join(process.env.JRE_HOME,  'bin', exe) : null,
    exe,
    isWin && 'C:\\Program Files\\Eclipse Adoptium\\jdk-21.0.5.11-hotspot\\bin\\java.exe',
    isWin && 'C:\\Program Files\\Eclipse Adoptium\\jdk-21.0.3.9-hotspot\\bin\\java.exe',
    isWin && 'C:\\Program Files\\Microsoft\\jdk-21.0.5.11-hotspot\\bin\\java.exe',
    isWin && 'C:\\Program Files\\Java\\jdk-21\\bin\\java.exe',
    isWin && 'C:\\Program Files\\Java\\jre-21\\bin\\java.exe',
    !isWin && '/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home/bin/java',
    !isWin && '/opt/homebrew/opt/openjdk@21/bin/java',
    !isWin && '/usr/local/opt/openjdk@21/bin/java',
    !isWin && '/usr/bin/java',
  ].filter(Boolean);

  for (const bin of candidates) {
    try {
      const out = execSync('"' + bin + '" -version 2>&1', { timeout: 5000, stdio: 'pipe' }).toString();
      const m   = out.match(/version "?(\d+)/);
      if (m && parseInt(m[1]) >= 17) {
        console.log('[java] detecte :', bin);
        return bin;
      }
    } catch {}
  }
  return null;
}

// ─── Download Fabric Installer ────────────────────────────────────────────────
async function downloadFabricInstaller(destDir, sender) {
  const dest = path.join(destDir, FABRIC_INSTALLER_JAR);
  if (fs.existsSync(dest)) {
    console.log('[installer] deja present');
    return dest;
  }

  sender && sender.send('launch-progress', { type: 'status', label: 'Telechargement Fabric Installer...', pct: 15 });

  const { data } = await axios.get(FABRIC_INSTALLER_URL, {
    responseType: 'arraybuffer',
    timeout: 30000,
    onDownloadProgress: function(e) {
      if (e.total) {
        var pct = 15 + Math.round((e.loaded / e.total) * 10);
        sender && sender.send('launch-progress', {
          type: 'status',
          label: 'Fabric Installer ' + Math.round(e.loaded / 1000) + ' KB',
          pct: pct,
        });
      }
    },
  });

  fs.mkdirSync(destDir, { recursive: true });
  fs.writeFileSync(dest, Buffer.from(data));
  console.log('[installer] sauvegarde :', dest);
  return dest;
}

// ─── Run Fabric Installer ─────────────────────────────────────────────────────
function runFabricInstaller(javaPath, installerJar, gameDir, sender) {
  return new Promise(function(resolve, reject) {
    sender && sender.send('launch-progress', { type: 'status', label: 'Installation Fabric 1.21.1...', pct: 30 });

    var args = ['-jar', installerJar, 'client', '-dir', gameDir, '-mcversion', MC_VERSION, '-noprofile'];
    console.log('[installer] commande :', javaPath, args.join(' '));
    sender && sender.send('launch-log', '> java ' + args.join(' '));

    var proc = spawn(javaPath, args, { shell: false });
    var output = [];

    proc.stdout.on('data', function(d) {
      var line = d.toString().trim();
      if (line) { output.push(line); sender && sender.send('launch-log', line); }
    });
    proc.stderr.on('data', function(d) {
      var line = d.toString().trim();
      if (line) { output.push(line); sender && sender.send('launch-log', line); }
    });
    proc.on('close', function(code) {
      console.log('[installer] exit code :', code);
      if (code === 0) {
        resolve(output.join('\n'));
      } else {
        reject(new Error('Fabric Installer echec (code ' + code + '):\n' + output.slice(-5).join('\n')));
      }
    });
    proc.on('error', function(err) { reject(err); });
  });
}

// ─── Resolve Fabric version ID ────────────────────────────────────────────────
async function resolveFabricVersionId(gameDir, sender) {
  sender && sender.send('launch-progress', { type: 'status', label: 'Resolution profil Fabric...', pct: 55 });

  var versionsDir = path.join(gameDir, 'versions');
  if (fs.existsSync(versionsDir)) {
    var entries = fs.readdirSync(versionsDir)
      .filter(function(d) { return d.startsWith('fabric-loader-') && d.endsWith('-' + MC_VERSION); })
      .sort().reverse();
    if (entries.length > 0) {
      console.log('[fabric] version locale :', entries[0]);
      return entries[0];
    }
  }

  console.log('[fabric] fallback API meta.fabricmc.net');
  var resp = await axios.get(FABRIC_META_URL, { timeout: 10000 });
  var data = resp.data;
  var loader = (data.find(function(l) { return l.loader.stable; }) || data[0]).loader.version;
  return 'fabric-loader-' + loader + '-' + MC_VERSION;
}

// ─── Mods dir ─────────────────────────────────────────────────────────────────
function ensureModsDir(gameDir) {
  var modsDir = path.join(gameDir, 'mods');
  if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir, { recursive: true });
  return modsDir;
}


// ─── Patch Fabric version JSON ────────────────────────────────────────────────
// Corrige le assetIndex dans le JSON Fabric pour pointer sur '1.21.1'
// et s'assure que le jar MC principal est bien dans le classpath
async function patchFabricVersionJson(root, fabricVersionId, sender) {
  var versionDir  = path.join(root, 'versions', fabricVersionId);
  var versionJson = path.join(versionDir, fabricVersionId + '.json');

  if (!fs.existsSync(versionJson)) {
    console.warn('[patch] version JSON introuvable :', versionJson);
    return;
  }

  var profile;
  try {
    profile = JSON.parse(fs.readFileSync(versionJson, 'utf-8'));
  } catch (e) {
    console.error('[patch] lecture JSON échouée :', e.message);
    return;
  }

  var patched = false;

  // 1. Forcer assetIndex sur '1.21.1'
  if (!profile.assetIndex || profile.assetIndex.id !== MC_VERSION) {
    profile.assetIndex = {
      id:           MC_VERSION,
      url:          'https://launchermeta.mojang.com/v1/packages/386d6e8de7a25a1fa7f842bf3ca36a73e823c75c/1.21.1.json',
      sha1:         '',
      size:         0,
      totalSize:    0
    };
    // Récupérer les vraies métadonnées assetIndex depuis Mojang
    try {
      var manifestResp = await axios.get(
        'https://launchermeta.mojang.com/mc/game/version_manifest_v2.json',
        { timeout: 10000 }
      );
      var mcMeta = manifestResp.data.versions.find(function(v) { return v.id === MC_VERSION; });
      if (mcMeta) {
        var mcJsonResp = await axios.get(mcMeta.url, { timeout: 10000 });
        if (mcJsonResp.data.assetIndex) {
          profile.assetIndex = mcJsonResp.data.assetIndex;
          // Copier aussi les downloads du jar MC si absent
          if (!profile.downloads && mcJsonResp.data.downloads) {
            profile.downloads = mcJsonResp.data.downloads;
          }
          // Copier la liste de libraries MC manquantes (natives etc.)
          if (mcJsonResp.data.libraries) {
            var fabricLibNames = (profile.libraries || []).map(function(l) { return l.name; });
            mcJsonResp.data.libraries.forEach(function(lib) {
              if (!fabricLibNames.includes(lib.name)) {
                profile.libraries = profile.libraries || [];
                profile.libraries.push(lib);
              }
            });
          }
        }
      }
      patched = true;
      sender && sender.send('launch-log', '[patch] assetIndex corrigé → ' + profile.assetIndex.id);
    } catch (e) {
      console.error('[patch] impossible de récupérer assetIndex Mojang :', e.message);
      // Fallback : assetIndex minimal fonctionnel
      profile.assetIndex = { id: MC_VERSION, url: '', sha1: '', size: 0, totalSize: 0 };
      patched = true;
    }
  }

  // 2. Forcer assets = 'legacy' ou MC_VERSION
  if (!profile.assets || profile.assets !== MC_VERSION) {
    profile.assets = MC_VERSION;
    patched = true;
  }

  if (patched) {
    fs.writeFileSync(versionJson, JSON.stringify(profile, null, 2));
    console.log('[patch] version JSON patché :', versionJson);
  } else {
    console.log('[patch] version JSON OK, aucun patch nécessaire');
  }
}

// ─── Main launch function ─────────────────────────────────────────────────────
async function launchFabric(session, root, ramG, sender) {
  ramG = ramG || 4;

  try {
    // 1 — Java
    sender && sender.send('launch-progress', { type: 'status', label: 'Recherche Java...', pct: 5 });
    var javaPath = detectJava();
    if (!javaPath) {
      return { success: false, noJava: true, error: 'Java 17+ introuvable. Installez Java 21 : https://adoptium.net' };
    }
    sender && sender.send('launch-log', 'Java : ' + javaPath);

    // 2 — Dossiers
    fs.mkdirSync(root, { recursive: true });
    ensureModsDir(root);

    // 3 — Telecharger l'installer Fabric
    var installerJar = await downloadFabricInstaller(root, sender);

    // 4 — Verifier si Fabric est deja installe
    sender && sender.send('launch-progress', { type: 'status', label: 'Verification Fabric...', pct: 25 });
    var versionsDir = path.join(root, 'versions');
    var alreadyInstalled = fs.existsSync(versionsDir) &&
      fs.readdirSync(versionsDir).some(function(d) {
        return d.startsWith('fabric-loader-') && d.endsWith('-' + MC_VERSION);
      });

    if (!alreadyInstalled) {
      await runFabricInstaller(javaPath, installerJar, root, sender);
    } else {
      console.log('[fabric] deja installe, skip');
      sender && sender.send('launch-log', 'Fabric deja installe.');
    }

    // 5 — Resoudre le versionId
    var fabricVersionId = await resolveFabricVersionId(root, sender);
    sender && sender.send('launch-progress', { type: 'status', label: 'Profil : ' + fabricVersionId, pct: 60 });
    sender && sender.send('launch-log', 'Profil Fabric : ' + fabricVersionId);

    // 5b — Patch critique : forcer assetIndex = '1.21.1' dans le JSON Fabric
    // MCLC ne suit pas 'inheritsFrom' pour assetIndex → il utilise l'ID du profil custom
    // ce qui donne --assetIndex fabric-loader-X.Y.Z-1.21.1 → MC crash (assets introuvables)
    await patchFabricVersionJson(root, fabricVersionId, sender);

    // 6 — Auth
    // _authObj = objet complet de minecraft-launcher-core (en memoire main process)
    // Si absent (session chargee du disque), on reconstruit un objet valide
    var authorization = session._authObj || {
      access_token:    session.accessToken  || '0',
      client_token:    session.clientToken  || session.uuid.replace(/-/g, ''),
      uuid:            session.uuid.replace(/-/g, ''),
      name:            session.username,
      user_properties: session.userProperties || '{}',
      meta: {
        type: session.type === 'microsoft' ? 'msa' : 'offline',
        demo: false,
        legacy: false,
      },
    };
    console.log('[launch] auth type:', authorization.meta && authorization.meta.type, '| user:', authorization.name);

    // 7 — Options launcher
    var launchOptions = {
      authorization: authorization,
      root: root,
      version: {
        number: MC_VERSION,
        type:   'release',
        custom: fabricVersionId,
      },
      memory: {
        max: ramG + 'G',
        min: Math.max(1, Math.floor(ramG / 2)) + 'G',
      },
      overrides: {
        gameDirectory: root,
        assetRoot:     path.join(root, 'assets'),   // chemin explicite des assets
        detached:      true,
        javaBin:       javaPath,
        javaArgs: [
          '-XX:+UseG1GC',
          '-XX:+ParallelRefProcEnabled',
          '-XX:MaxGCPauseMillis=200',
          '-XX:+UnlockExperimentalVMOptions',
          '-XX:+DisableExplicitGC',
          '-XX:+AlwaysPreTouch',
          '-XX:G1NewSizePercent=30',
          '-XX:G1MaxNewSizePercent=40',
          '-XX:G1HeapRegionSize=8M',
          '-XX:G1ReservePercent=20',
          '-XX:G1HeapWastePercent=5',
          '-XX:G1MixedGCCountTarget=4',
          '-XX:InitiatingHeapOccupancyPercent=15',
          '-XX:G1MixedGCLiveThresholdPercent=90',
          '-XX:G1RSetUpdatingPauseTimePercent=5',
          '-XX:SurvivorRatio=32',
          '-XX:+PerfDisableSharedMem',
          '-XX:-OmitStackTraceInFastThrow',
        ],
      },
    };

    // 8 — Lancement
    sender && sender.send('launch-progress', { type: 'status', label: 'Demarrage Minecraft...', pct: 75 });

    // ── Filtre les args "fixedMinecraft" injectés automatiquement par MCLC ──────
    // MCLC v3 ajoute -XX:-UseAdaptiveSizePolicy, -Dfml.ignorePatchDiscrepancies=true,
    // -Dfml.ignoreInvalidMinecraftCertificates=true — inutiles sous Fabric, on les retire.
    var origSpawn = require('child_process').spawn;
    var _cp = require('child_process');
    var BLOCKED_ARGS = [
      '-XX:-UseAdaptiveSizePolicy',
      '-Dfml.ignorePatchDiscrepancies=true',
      '-Dfml.ignoreInvalidMinecraftCertificates=true',
      '-XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump',
    ];
    _cp.spawn = function(cmd, args, opts) {
      if (Array.isArray(args)) {
        var before = args.length;
        args = args.filter(function(a) {
          return !BLOCKED_ARGS.includes(a);
        });
        if (args.length !== before) {
          console.log('[launch] args filtrés (' + (before - args.length) + ' retirés) :', BLOCKED_ARGS.filter(function(b){ return !args.includes(b); }));
        }
      }
      return origSpawn(cmd, args, opts);
    };

    var client = new Client();

    client.on('debug', function(msg) { console.log('[MC]', msg); });
    client.on('data',  function(msg) { sender && sender.send('launch-log', String(msg).trim()); });
    client.on('progress', function(data) {
      var pct = data.total ? Math.round((data.task / data.total) * 100) : 0;
      sender && sender.send('launch-progress', {
        type:  'download',
        label: (data.type || 'assets') + ' (' + (data.task || 0) + '/' + (data.total || '?') + ')',
        pct:   75 + Math.round(pct * 0.22),
      });
    });
    client.on('close', function(code) {
      console.log('[MC] ferme code', code);
      // Restaurer spawn original
      _cp.spawn = origSpawn;
      sender && sender.send('launch-closed', code);
    });

    await client.launch(launchOptions);

    sender && sender.send('launch-progress', { type: 'status', label: 'Minecraft lance !', pct: 100 });
    return { success: true, username: session.username, version: fabricVersionId };

  } catch (err) {
    console.error('[launchFabric] ERREUR :', err.message);
    return { success: false, error: err.message };
  }
}

module.exports = { launchFabric, detectJava, ensureModsDir };
