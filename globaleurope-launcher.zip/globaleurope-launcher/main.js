const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const http = require('http');
const axios = require('axios');
const admZip = require('adm-zip');
const auth        = require('./auth');
const launcherCore = require('./launcher-core');

let mainWindow;
let currentSession = null;  // session active en mémoire
const isDev = process.argv.includes('--dev');

// ─── Paths ───────────────────────────────────────────────────────────────────
const MINECRAFT_DIR = path.join(
  process.env.APPDATA || process.env.HOME,
  isDev ? '.globaleurope-dev' : '.globaleurope'
);
const MODS_DIR   = path.join(MINECRAFT_DIR, 'mods');
const MODS_JSON  = path.join(__dirname, 'mods.json');
const GIST_URL   = 'https://gist.githubusercontent.com/raw/mods.json'; // À remplacer par votre vrai Gist URL
// ⚠️  CONFIGURER : URL directe vers votre mods.zip hébergé
// Ex: OneDrive direct link, Google Drive, votre propre serveur, etc.
const MODS_ZIP_URL = process.env.GE_MODS_URL || 'https://cdn.discordapp.com/attachments/1087394123344003225/1479115076886593658/mods.zip?ex=69aadcc2&is=69a98b42&hm=b3c8c9acd56519628831eeafce67135c8181dd83e1615bd65117982c5c8b2618&';

// ─── Window ──────────────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 680,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    transparent: false,
    resizable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#0a0f1e',
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(async () => {
  // Restaurer la session sauvegardee et rafraichir si necessaire
  const saved = auth.loadSession();
  if (saved) {
    // Invalider les vieilles sessions où uuid = username (bug MCLC)
    const uuidOk = saved.uuid && saved.uuid.includes('-') && saved.uuid.length === 36;
    if (!uuidOk) {
      console.log('[main] session invalide (uuid=' + saved.uuid + '), suppression');
      auth.clearSession();
    } else {
      currentSession = await auth.refreshSessionIfNeeded(saved).catch(() => null);
    }
  }
  createWindow();
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!mainWindow) createWindow(); });

// ─── IPC Handlers ────────────────────────────────────────────────────────────

// Window controls

// Auth : recupere la session active (serialisee)
ipcMain.handle('auth-get-session', () => auth.serializeSession(currentSession));

// Auth : connexion Microsoft (msmc — dynamic import)
ipcMain.handle('auth-microsoft', async () => {
  try {
    currentSession = await auth.microsoftLogin(mainWindow);
    // serializeSession() retire les champs non-clonables (fonctions, objets complexes)
    return { success: true, session: auth.serializeSession(currentSession) };
  } catch (err) {
    console.error('[auth-microsoft]', err.message);
    let msg = err.message || 'Erreur inconnue';
    if (msg.includes('cancel') || msg.includes('annul') || msg.includes('closed'))
      msg = 'Connexion annulée';
    else if (msg.includes('XErr'))
      msg = 'Compte Xbox requis — créez un compte sur xbox.com';
    else if (msg.includes('AADSTS'))
      msg = 'Erreur Azure AD : ' + msg;
    else if (msg.includes('Auth') && msg.includes('constructor'))
      msg = 'msmc: vérifiez que la version 3.x est bien installée (npm install msmc@3)';
    return { success: false, error: msg };
  }
});

// Auth : connexion hors-ligne
ipcMain.handle('auth-offline', async (_, username) => {
  try {
    currentSession = auth.createOfflineSession(username);
    // IMPORTANT: on retourne serializeSession, pas currentSession brut
    // car authObj contient des propriétés non-clonables par IPC
    return { success: true, session: auth.serializeSession(currentSession) };
  } catch (err) {
    console.error('[auth-offline]', err.message);
    return { success: false, error: err.message };
  }
});

// Auth : deconnexion
ipcMain.handle('auth-logout', async () => {
  currentSession = null;
  auth.clearSession();
  return { success: true };
});

ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => mainWindow?.close());

// Open external URLs
ipcMain.on('open-external', (_, url) => shell.openExternal(url));

// Open shop
ipcMain.on('open-shop', () => shell.openExternal('https://pay.globaleurope.fr'));

// Open website
ipcMain.on('open-website', () => shell.openExternal('https://globaleurope.fr'));

// Open Discord
ipcMain.on('open-discord', () => shell.openExternal('https://discord.gg/globaleurope'));

// Copy IP to clipboard
ipcMain.handle('copy-ip', async () => {
  const { clipboard } = require('electron');
  clipboard.writeText('play.globaleurope.fr');
  return true;
});

// Get mods list
ipcMain.handle('get-mods', async () => {
  try {
    const data = fs.readFileSync(MODS_JSON, 'utf-8');
    return JSON.parse(data);
  } catch {
    return { mods: [] };
  }
});

// Check server status (ping)
ipcMain.handle('check-server', async () => {
  return new Promise((resolve) => {
    const req = http.request(
      { hostname: 'globaleurope.fr', port: 25565, method: 'HEAD', timeout: 3000 },
      () => resolve({ online: true })
    );
    req.on('error', () => resolve({ online: false }));
    req.on('timeout', () => { req.destroy(); resolve({ online: false }); });
    req.end();
  });
});

// Get installed mods
ipcMain.handle('get-installed-mods', async () => {
  try {
    if (!fs.existsSync(MODS_DIR)) return [];
    return fs.readdirSync(MODS_DIR).filter(f => f.endsWith('.jar'));
  } catch {
    return [];
  }
});

// Launch Minecraft — Fabric 1.21.1 réel via minecraft-launcher-core
ipcMain.handle('launch-game', async (event) => {
  if (!currentSession) {
    return { success: false, error: 'Non connecté — veuillez vous authentifier.' };
  }

  // Refresh token si besoin avant de lancer
  currentSession = await auth.refreshSessionIfNeeded(currentSession).catch(() => currentSession);

  // Lire la RAM choisie (stockée dans settings.json, défaut 4G)
  let ramG = 4;
  try {
    const settingsPath = require('path').join(MINECRAFT_DIR, 'launcher_settings.json');
    if (require('fs').existsSync(settingsPath)) {
      const s = JSON.parse(require('fs').readFileSync(settingsPath, 'utf-8'));
      ramG = parseInt(s.ram) || 4;
    }
  } catch {}

  // S'assurer que le dossier mods existe
  launcherCore.ensureModsDir(MINECRAFT_DIR);

  return await launcherCore.launchFabric(currentSession, MINECRAFT_DIR, ramG, event.sender);
});

// Download mods (real: télécharge mods.zip puis extrait avec adm-zip)
ipcMain.handle('download-mods', async (event) => {
  const zipPath = path.join(MINECRAFT_DIR, 'mods.zip');

  try {
    // 1 — Créer les dossiers si absents
    if (!fs.existsSync(MINECRAFT_DIR)) fs.mkdirSync(MINECRAFT_DIR, { recursive: true });
    if (!fs.existsSync(MODS_DIR))      fs.mkdirSync(MODS_DIR,      { recursive: true });

    // 3 — Téléchargement du ZIP avec suivi de progression
    event.sender.send('download-progress', { pct: 0, name: 'Connexion au serveur…', done: 0, total: 100 });

    const response = await axios.get(MODS_ZIP_URL, {
      responseType: 'arraybuffer',
      timeout: 120_000,
      onDownloadProgress: (progressEvent) => {
        if (progressEvent.total) {
          const pct = Math.round((progressEvent.loaded / progressEvent.total) * 80); // 0–80%
          const mb  = (progressEvent.loaded / 1_000_000).toFixed(1);
          const tot = (progressEvent.total   / 1_000_000).toFixed(1);
          event.sender.send('download-progress', {
            pct,
            name: `Téléchargement… ${mb} / ${tot} MB`,
            done: progressEvent.loaded,
            total: progressEvent.total,
          });
        }
      },
    });

    // 3 — Écriture du ZIP sur disque
    event.sender.send('download-progress', { pct: 82, name: 'Écriture sur le disque…', done: 82, total: 100 });
    fs.writeFileSync(zipPath, response.data);

    // 4 — Extraction avec adm-zip
    event.sender.send('download-progress', { pct: 88, name: 'Extraction des mods…', done: 88, total: 100 });
    const zip = new admZip(zipPath);
    zip.extractAllTo(MODS_DIR, /* overwrite */ true);

    // 5 — Nettoyage du ZIP temporaire
    event.sender.send('download-progress', { pct: 96, name: 'Nettoyage…', done: 96, total: 100 });
    fs.unlinkSync(zipPath);

    // 6 — Terminé
    event.sender.send('download-progress', { pct: 100, name: '✅ Installation terminée !', done: 100, total: 100 });
    return { success: true };

  } catch (err) {
    console.error('[download-mods] Erreur :', err.message);

    // Nettoyage en cas d'échec
    try { if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath); } catch {}

    return { success: false, error: err.message };
  }
});

// Open mods folder
ipcMain.on('open-mods-folder', () => {
  if (!fs.existsSync(MODS_DIR)) fs.mkdirSync(MODS_DIR, { recursive: true });
  shell.openPath(MODS_DIR);
});

// Get app version
ipcMain.handle('get-version', () => app.getVersion());
ipcMain.handle('get-mods-dir', () => MODS_DIR);

// Sauvegarder les paramètres du launcher
ipcMain.handle('save-settings', async (_, settings) => {
  try {
    const settingsPath = path.join(MINECRAFT_DIR, 'launcher_settings.json');
    if (!fs.existsSync(MINECRAFT_DIR)) fs.mkdirSync(MINECRAFT_DIR, { recursive: true });
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

// Charger les paramètres du launcher
ipcMain.handle('load-settings', async () => {
  try {
    const settingsPath = path.join(MINECRAFT_DIR, 'launcher_settings.json');
    if (!fs.existsSync(settingsPath)) return { ram: 4 };
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return { ram: 4 };
  }
});

// Vérifier Java
ipcMain.handle('check-java', async () => {
  const javaPath = launcherCore.detectJava();
  return { found: !!javaPath, path: javaPath };
});

